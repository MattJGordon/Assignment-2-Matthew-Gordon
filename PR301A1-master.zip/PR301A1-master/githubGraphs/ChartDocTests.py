"""
>>>from BarGraph import BarGraph
>>>bar_graph = BarGraph('the title'[0], [0], [0])
>>>bar_graph.test_title()
'the title'
"""