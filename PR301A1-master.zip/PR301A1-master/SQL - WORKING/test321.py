import sqlite3
print (classmethod(sqlite3))
print (dir(sqlite3))
print (help(sqlite3.Connection))